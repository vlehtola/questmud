For the pictures I used the fonts Caeldera and Walshes.
For the text I used the default font.
All helpfiles are in the dir hfiles.
All guildfiles are in the dir guilds.
All eventfiles are int the dir events.


These are the framenames used..
in eventsfiles,mailindex,guildfiles,helpfiles,racefiles and the worldmapfiles.
Frames:  eventsMain
         mainFrame
         guildMain
         HelpFiles
         RaceFrame
         worldFrame

