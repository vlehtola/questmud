inherit "obj/armour";

reset(arg) {
    ::reset(arg);
    set_name("bat cloak");
    set_alias("cloak");
set_short("A finely made bat cloak");
set_long("You see a finely made cloak for bats.\n");
    set_ac(15);
    set_value(5000);
set_weight(100);
    set_stats("str", 2);
    set_stats("hpr", 3);
set_slot("cloak");
}                    
