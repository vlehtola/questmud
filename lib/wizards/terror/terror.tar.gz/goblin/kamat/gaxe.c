inherit "obj/weapon";
reset(arg) {
::reset(arg);
set_name("axe");
set_alias("axe");
set_short("A blood dripping axe");
set_long("A blood dripping axe used by goblins.\n");
set_weapon_type("axe");
set_wc(40);
set_value(500);
set_weight(600);
}
