inherit "obj/armour";
reset(arg) {
::reset(arg);
set_name("leggings");
set_alias("leggings");
set_short("A pair of water leggings");
set_long("You see a blue water dirty water leggins in front of you.\n");
set_ac(60);
set_value(30000);
set_weight(60);
set_stats("wis", 8);
set_stats("int", 7);
set_stats("spr", 10);
set_slot("legs");
}
