inherit "obj/weapon";
reset(arg) {
::reset(arg);
set_name("whip");
set_alias("ruaska");
set_short("A golden whip");
set_long("You see a tiny shining golden whip in front of your face.\n");
set_wc(45);
set_weight(1700);
set_value(9000);
set_weapon_type("bludgeon");
}
