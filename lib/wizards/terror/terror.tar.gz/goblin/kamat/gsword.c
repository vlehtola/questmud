inherit "obj/weapon";
reset(arg) {
::reset(arg);
set_name("sword");
set_alias("sword");
set_short("A rusty copper sword");
set_long("This sword is typicaly used by goblins.\n");
set_wc(38);
set_weapon_type("blade");
set_value(200);
set_weight(200);
}
