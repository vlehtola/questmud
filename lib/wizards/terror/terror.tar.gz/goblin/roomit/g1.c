inherit "room/room";
reset(arg) {
add_exit("south","/wizards/terror/goblin/roomit/g2.c");
add_exit("leave","/wizards/terror/goblin/roomit/ente.c");
short_desc = "A dark forest";
long_desc ="As you enter the forest you see that here really is alive.\n"+
"You smell the frest air in your nose and you feel good.\n"+
"The path is leading to out of forest and south.\n";
"You see many pairs of eyes behind the bushes.\n";
}
