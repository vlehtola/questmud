inherit "room/room";
reset(arg) {
add_exit("cs","/world/city/cs");
add_exit("maget","/world/mage/mag/tower1");
add_exit("goblin","/wizards/terror/goblin/roomit/ente.c");
add_exit("test", "/world/fighter/defender");
add_exit("abj","/world/mage/abj/tower1");
add_exit("agr","/world/fighter/acrobats");
add_exit("ber","/world/fighter/berserker");
add_exit("bar","/world/fighter/barbaria");
add_exit("post","/world/city/post");
add_exit("ran","/world/fighter/ranger");
short_desc = "Terrorin teleport place";
long_desc = "This room is made for Terror and his teleportation.\n";
}
