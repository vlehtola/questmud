#include "/world/guilds/guild.h"
#include "room.h"

#undef EXTRA_RESET
#define EXTRA_RESET\
        extra_reset();

object plaque;

init() {
    ::init();
    ::guild_init();
    add_action("join", "join");
    add_action("advance", "advance");
    add_action("info", "info");
    add_action("list", "list");
    add_action("check_advance_rec", "requirements");
    add_action("train", "train");
}

extra_reset() {
     if (!plaque) {
         plaque = clone_object("world/guilds/plaque.c");
         move_object(plaque, this_object()); 
     }
}

guild_long_name() {
    return "the Advanced Diviners.   ";
}

guild_name() {
    return "Advanced Diviners";
}

guild_max_level() {
    return 5;
}

check_joining_rec() {
    if (this_player()->query_guild_level(call_other("/world/guilds/guildfun.c", "get_guild_number", "Diviners")) != 5) {
        write("Must have completed the Diviners first.\n");
        return 0;
    }
    return 1;
}

check_advance_rec(lev) {
    int ii, i, req, req_level;
    string skill;
    req = allocate(10);
    req_level = allocate(10);
    skill = allocate(10);
    if (lev == 5 || !lev) {
        if (this_player()->query_skills(get_num("cast greater")) < 50 || !lev) {
            req[i] = 50; skill[i] = "cast greater";
            req_level[i] = 5;
            i += 1;
        }
    }
    if (!lev) { check_joining_rec(); }
    while(ii < i) {
        write("Level " + req_level[ii] + ": Must have trained skill " + skill[ii] + " to at least " + req[ii] + "% (" + this_player()->query_skills(get_num(skill[ii])) + "%).\n");
        ii += 1;
    }
    if (i && lev) { return 0; }
    return 1;
}

/*
    5% Int, 15% Wis, 10% Con, 5 spregen
*/

get_bonuses(level) {
    if (level == 0) {
        return "wis 1 , con 1 , int 1 , spregen 1 , ";
    }
    if (level == 1) {
        return "wis 2 , con 1 , int 1 , ";
    }
    if (level == 2) {
        return "wis 3 , con 1 , spregen 1 , ";
    }
    if (level == 3) {
        return "wis 4 , con 3 , int 1 , ";
    }
    if (level == 4) {
        return "wis 5 , con 4 , int 2 , spregen 3 , ";
    }
}
/*    
   Cast greater: 100
   channel: 60
   quick chant: 35
*/

get_skill_max(num, how, lvl) {
    int skill_max, skill_num, i, guild_level;
    guild_level = this_player()->query_guild_level(call_other("/world/guilds/guildfun", "get_guild_number", guild_name()));
    if (lvl) {
         guild_level = lvl;
         if (guild_level > guild_max_level()) { guild_level = guild_max_level(); }
         if (guild_level < 1) { guild_level = 1; }
    }
    if (!guild_level) {
        write("Bugged.. not a member\n");
        return 0;
    }
    if (guild_level == 1) {
        skill_max = allocate(3);
        skill_num = allocate(3);
        skill_num[0] = get_num("cast greater");
        skill_max[0] = 20;
        skill_num[1] = get_num("channel");
        skill_max[1] = 55;
        skill_num[2] = get_num("quick chant");
        skill_max[2] = 30;
    }
    if (guild_level == 2) {
        skill_max = allocate(3);
        skill_num = allocate(3);
        skill_num[0] = get_num("cast greater");
        skill_max[0] = 40;
        skill_num[1] = get_num("channel");
        skill_max[1] = 55;
        skill_num[2] = get_num("quick chant");
        skill_max[2] = 35;
    }
    if (guild_level == 3) {
        skill_max = allocate(3);
        skill_num = allocate(3);
        skill_num[0] = get_num("cast greater");
        skill_max[0] = 60;
        skill_num[1] = get_num("channel");
        skill_max[1] = 60;
        skill_num[2] = get_num("quick chant");
        skill_max[2] = 35;
    }
    if (guild_level == 4) {
        skill_max = allocate(3);
        skill_num = allocate(3);
        skill_num[0] = get_num("cast greater");
        skill_max[0] = 80;
        skill_num[1] = get_num("channel");
        skill_max[1] = 60;
        skill_num[2] = get_num("quick chant");
        skill_max[2] = 40;
    }
    if (guild_level == 5) {
        skill_max = allocate(3);
        skill_num = allocate(3);
        skill_num[0] = get_num("cast greater");
        skill_max[0] = 100;
        skill_num[1] = get_num("channel");
        skill_max[1] = 65;
        skill_num[2] = get_num("quick chant");
        skill_max[2] = 40;
    }
    if (how == 0) {
        while (i < sizeof(skill_max)) {
            if (skill_num[i] == num) {
                return skill_max[i];
            }
            i += 1;
        }  
    }
    if (how == 1) {
        return skill_max[num];
    }
    if (how == 2) {
        return skill_num[num];
    }
    if (how == 3) {
        return call_other("obj/skillfun", "skill_names", skill_num[num]);
    }
    if (how == 4) {
        return skill_max;
    }
}

TWO_EXIT("world/cleric/adeptdiv","up",
         "world/cleric/diviners","down",
         "The Advanced Diviners balcony",
         "You are standing on a balcony on the fourth floor of the church.\n"+
         "This is where clerics start learning how to better apply the\n"+
         "power of their god. Sounds of a chorus echoes in the church.\n"+
         "There is a stairway leading up and down.\n", 3)

