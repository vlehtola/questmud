inherit "room/room";

reset(arg) {
   if (arg) return;
   add_exit("east", "world/cleric/apprcler");
   add_exit("north", "world/cleric/cyral_center");
   short_desc = "Altar room of Cyral the Sacred";
   long_desc =
"You are in the altar room of Cyral the Sacred. There is a white altar\n"+
"in the middle of the room. Here you can sacrifice and pray to Cyral.\n";

   if (!present("priest")) {
     move_object(clone_object("world/cleric/monsters/adept1"),this_object());
   }
   items = allocate(2);
   items[0] = "altar";
   items[1] = 
"The altar is made of white marble. You could 'sacrifice' on it and 'pray'";
}

init() {
   ::init();
   add_action("pray","pray");
   add_action("sacrifice", "sacrifice");
}

pray(arg) {
   if (arg) write("You pray to Cyral.\n");

   if (this_player()->query_god_status() < -50) {
	write("You feel Cyral is angry to you.\n");
	return 1;
   }
   if (this_player()->query_god_status() < 0) {
        write("Nothing happens.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 10) {
        write("You feel Cyral is unconcerned.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 35) {
        write("You feel Cyral is interessed.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 60) {
        write("You feel Cyral is pleased.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 90) {
        write("You feel Cyral is very pleased.\n");
        return 1;
   }
   write("You sense Cyral very close to you.\n");
   return 1;
}


sacrifice(str) {
   object ob;
   int i;
   if (!str) { write("Sacrifice what?\n"); return 1; }

   ob = present(str, this_player());
   if (!ob) { write("You don't have a "+capitalize(str)+".\n"); return 1; }
   if (ob->drop()) { write("You can't sacrifice it.\n"); return 1;}

   i = ob->query_value();
   if (ob->query_corpse()) { i += 1000 + ob->query_level() * 30; }
   if (ob->query_corpse() && !ob->query_animal()) {
	write("The ground rumbles for a moment.\n");
	this_player()->add_god_status(-1);
	move_object(ob, this_object());
	return 1;
   }
   if (i < 500) {
	write("Nothing happens.\n");
	move_object(ob, this_object());
	return 1;
   }
   write(capitalize(str)+" is consumed in a white flame.\n");
   i = i / 500;
   this_player()->add_god_status(i);
   destruct(ob);
   pray(1);
   return 1;
}

query_cyral_altar() { return 1; }
