inherit "room/room";

reset(arg) {
   if (arg) return;
   add_exit("east", "world/cleric/church2");
   short_desc = "Altar room of Cyral the Sacred";
   long_desc =
"You are in the altar room of Cyral the Sacred. There is a white altar\n"+
"in the middle of the room. Here you can sacrifice and pray to Cyral.\n";

   if (!present("priest")) {
     move_object(clone_object("world/cleric/monsters/adept1"),this_object());
   }
   items = allocate(2);
   items[0] = "altar";
   items[1] = 
"The altar is made of white marble. You could 'sacrifice' on it and 'pray'";
}

init() {
   ::init();
   add_action("pray","pray");
}

pray() {
   write("You pray to Cyral.\n");

   if (this_player()->query_god_status() < -50) {
	write("You feel Cyral is angry to you.\n");
	return 1;
   }
   if (this_player()->query_god_status() < 0) {
        write("Nothing happens.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 30) {
        write("You feel Cyral is unconcerned.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 60) {
        write("You feel Cyral is pleased.\n");
        return 1;
   }
   if (this_player()->query_god_status() < 90) {
        write("You feel Cyral is very pleased.\n");
        return 1;
   }
   write("You sense Cyral very close to you.\n");
   return 1;
}


