inherit "room/room";

reset(arg) {
   if (arg) return;
   add_exit("west", "world/cleric/church2");
   short_desc = "Altar room of Morai the Betrayer";
   long_desc =
"You are in the altar room of Morai the Betrayer. There is a black altar\n"+
"in the middle of the room. Here you can sacrifice and pray to Morai.\n";

   if (!present("priest")) {
	move_object(clone_object("world/cleric/monsters/adept2"),this_object());
   }
   items = allocate(2);
   items[0] = "altar";
   items[1] =
"The altar is made of black stone. You could 'sacrifice' on it and 'pray'";
}

init() {
   ::init();
   add_action("pray","pray");
}

pray() {
   write("You pray to Morai.\n");
   if (this_player()->query_god_status() > 50) {
	write("You feel Morai is angry to you.\n");
	return 1;
   }
   if (this_player()->query_god_status() > 0) {
	write("Nothing happens.\n");
	return 1;
   }
   if (this_player()->query_god_status() > -30) {
	write("You feel Morai is unconcerned.\n");
	return 1;
   }
   if (this_player()->query_god_status() > -30) {
	write("You feel Morai is pleased.\n");
	return 1;
   }
   if (this_player()->query_god_status() > -90) {
	write("You feel Morai is very pleased.\n");
	return 1;
   }
   write("You sense Morai very close to you.\n");
   return 1;
}
