#include "/world/guilds/guild.h"
#include "room.h"

#undef EXTRA_RESET
#define EXTRA_RESET\
        extra_reset();

init() {
    ::init();
    add_action("join", "join");
    add_action("advance", "advance");
    add_action("info", "info");
    add_action("list", "list");
    add_action("check_advance_rec", "requirements");
    add_action("train", "train");
}    

extra_reset() {
     object plaque,ob;
     if (!present("plaque")) {
     	plaque = clone_object("world/guilds/plaque.c");
     	move_object(plaque, this_object()); 
     }
     if(!ob) {
	ob = clone_object("/wizards/celtron/monk");
	move_object(ob, this_object());
    }
}

guild_long_name() {
    return "the Apprentice Clerics. ";
}

guild_name() {
    return "Apprentice Clerics";
}

guild_max_level() {
    return 10;
}

check_joining_rec() {
    return 1;
}

check_advance_rec(lev) {
    int ii, i, req, req_level;
    string skill;
    req = allocate(10);
    req_level = allocate(10);
    skill = allocate(10);
    if (lev == 2 || !lev) {
        if (this_player()->query_skills(get_num("cast divine")) < 20 || !lev) {
            req[i] = 20; skill[i] = "cast divine";
            req_level[i] = 2;
            i += 1;
        }
        if (this_player()->query_skills(get_num("cast heal")) < 20 || !lev) {
            req[i] = 20; skill[i] = "cast heal";
            req_level[i] = 2;
            i += 1;
        }
        if (this_player()->query_skills(get_num("cast minor")) < 10 || !lev) {
            req[i] = 20; skill[i] = "cast minor";
            req_level[i] = 2;
            i += 1;
        }
        if (this_player()->query_skills(get_num("channel")) < 10 || !lev) {
            req[i] = 10; skill[i] = "channel";
            req_level[i] = 2;
            i += 1;
        }
    
    }
    if (lev == 6 || !lev) {
        if (this_player()->query_skills(get_num("channel")) < 30 || !lev) {
            req[i] = 30; skill[i] = "channel";
            req_level[i] = 6;
            i += 1;
        }
    }
    if (lev == 10 || !lev) {
        if (this_player()->query_skills(get_num("cast divine")) < 40 || !lev) {
            req[i] = 40; skill[i] = "cast divine";
            req_level[i] = 10;
            i += 1;
        }
    }
    if (!lev) { check_joining_rec(); }
    while(ii < i) {
        write("Level " + req_level[ii] + ": Must have trained '" + skill[ii] + "' to at least " + req[ii] + "% (" + this_player()->query_skills(get_num(skill[ii])) + "%).\n");
        ii += 1;
    }
    if (i && lev) { return 0; }
    return 1;
}

/*
    10% Int, 25% Wis, 15% Con
*/

get_bonuses(level) {
    if (level == 0) {
        return "con 1 , wis 1 , spregen 2 , ";
    }
    if (level == 1) {
        return "int 1 , wis 1 , ";
    }
    if (level == 2) {
        return "con 2 , wis 2 , spregen 1 , ";
    }
    if (level == 3) {
        return "con 2 , int 2 , wis 2 , ";
    }
    if (level == 4) {
        return "int 1 , wis 1 , spregen 2 , ";
    }
    if (level == 5) {
        return "con 2 , int 1 , wis 2 , ";
    }
    if (level == 6) {
        return "int 1 , wis 2 , spregen 3 , ";
    }
    if (level == 7) {
        return "con 3 , int 2 , wis 3 , ";
    }
    if (level == 8) {
        return "con 1 , int 2 , wis 4 , ";
    }
    if (level == 9) {
        return "con 5 , wis 7 , spregen 10 , ";
    }
}
/*    
   Attack: 30
   Bare hands: 40
   Chanting: 60
   Cast damage: 60
   Cast fire: 60
   Cast grasp: 60
   channel: 40
*/

get_skill_max(num, how, lvl) {
    int skill_max, skill_num, i, guild_level;
    guild_level = this_player()->query_guild_level(call_other("/world/guilds/guildfun", "get_guild_number", guild_name()));
    if (lvl) {
         guild_level = lvl;
         if (guild_level > 10) { guild_level = 10; }
         if (guild_level < 1) { guild_level = 1; }
    }
    if (!guild_level) {
        write("Bugged.. not a member\n");
        return 0;
    }
    if (guild_level == 1) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 10;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 30;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 30;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 30;
        skill_num[4] = get_num("channel");
        skill_max[4] = 10;
    }
    if (guild_level == 2) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 10;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 40;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 40;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 40;
        skill_num[4] = get_num("channel");
        skill_max[4] = 20;
    }
    if (guild_level == 3) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 10;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 40;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 40;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 50;
        skill_num[4] = get_num("channel");
        skill_max[4] = 20;
    }
    if (guild_level == 4) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 20;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 40;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 40;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 50;
        skill_num[4] = get_num("channel");
        skill_max[4] = 30;
    }
    if (guild_level == 5) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 30;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 40;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 45;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 60;
        skill_num[4] = get_num("channel");
        skill_max[4] = 30;
    }
    if (guild_level == 6) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 40;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 50;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 45;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 60;
        skill_num[4] = get_num("channel");
        skill_max[4] = 30;
    }
    if (guild_level == 7) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 50;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 50;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 45;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 70;
        skill_num[4] = get_num("channel");
        skill_max[4] = 30;
    }
    if (guild_level == 8) {
        skill_max = allocate(5);
        skill_num = allocate(5);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 60;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 60;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 50;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 80;
        skill_num[4] = get_num("channel");
        skill_max[4] = 40;
    }
    if (guild_level == 9) {
        skill_max = allocate(6);
        skill_num = allocate(6);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 70;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 60;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 50;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 90;
        skill_num[4] = get_num("channel");
        skill_max[4] = 40;
        skill_num[5] = get_num("quick chant");
        skill_max[5] = 10;
    }
    if (guild_level == 10) {
        skill_max = allocate(6);
        skill_num = allocate(6);
        skill_num[0] = get_num("chanting");
        skill_max[0] = 70;
        skill_num[1] = get_num("cast divine");
        skill_max[1] = 70;
        skill_num[2] = get_num("cast heal");
        skill_max[2] = 50;
        skill_num[3] = get_num("cast minor");
        skill_max[3] = 100;
        skill_num[4] = get_num("channel");
        skill_max[4] = 40;
        skill_num[5] = get_num("quick chant");
        skill_max[5] = 20;
    }                  
    if (how == 0) {
        while (i < sizeof(skill_max)) {
            if (skill_num[i] == num) {
                return skill_max[i];
            }
            i += 1;
        }  
    }
    if (how == 1) {
        return skill_max[num];
    }
    if (how == 2) {
        return skill_num[num];
    }
    if (how == 3) {
        return call_other("obj/skillfun", "skill_names", skill_num[num]);
    }
    if (how == 4) {
        return skill_max;
    }
}

special_advance_effect(lvl) {
    object book;
    if (!present("spellbook", this_player())) {
        write("Suddenly you notice an old man standing beside the altar.\n" +
              "He walks to you and says '" + this_player()->query_name() +
              ", it is time for you to recieve your holy book\n" +
              "of spells'. He hands you a book with pure white covers.\n" +
              "And he continues 'Serve me well my ");
        if (this_player()->query_gender() == 1) { write("son"); }
        if (this_player()->query_gender() == 2) { write("daughter"); }
        write(" and you will be\n" +
              "saved'. As suddenly as he came, he is gone, but the book remains.\n");
        book = clone_object("obj/clericbo.c");
        move_object(book, this_player());
        book->add_spell("Minor Heal", "chl hea min");
    }    
}

FIVE_EXIT("world/cleric/apprdivi","west",
         "world/city/mainstr4","south",
         "world/cleric/healer","north",
	 "world/cleric/cleric","east",
	 "world/cleric/priest","up",
         "The Apprentice Clerics chapel",
         "The Apprentice Clerics chapel.\n"+
         "You are standing in a small chapel. The walls are made of pure\n" +
         "white marble. A peaceful silence rests upon you. You feel this is\n" +
         "the right place to pray and thank your god for everything.\n", 3)

