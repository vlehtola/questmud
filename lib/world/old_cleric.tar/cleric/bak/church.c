inherit "room/room";

reset(arg) {
   if (arg) return;
   add_exit("north", "world/cleric/church2");
   add_exit("south", "world/city/mainstr4");
   short_desc = "Church entrance";
   long_desc =
"You have entered the church of Duranghom. The ceiling raises high above\n"+
"your head. The walls are covered with pictures and windows are made of\n"+ 
"colourful glass mosaics. Everything is decorated with gold. The air is\n"+
"filled with an odour of some sweet incence. You can hear a chorus\n"+
"singing in the distance.\n";
   set_not_out(1);
   set_light(3);
}
