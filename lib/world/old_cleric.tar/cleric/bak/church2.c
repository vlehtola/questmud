inherit "room/room";

reset(arg) {
   if (arg) return;
   add_exit("north", "/world/cleric/apprcler");
   add_exit("south", "/world/cleric/church");
   add_exit("west", "/world/cleric/altar1");
   add_exit("east", "/world/cleric/altar2");
   short_desc = "Church";
   long_desc =
"You are in the church of Duranghom. The ceiling raises high above your\n"+
"head. Everything is decorated with gold. The singing of a chorus echoes\n"+
"in here. An odour of some sweet insence fills the air.\n"+
"There are altars both in east and in west.\n";

   if (!present("priest")) {
	move_object(clone_object("world/cleric/monsters/priest"),this_object());
   }
}
