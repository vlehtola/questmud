#include "/world/guilds/guild.h"
#include "room.h"

#undef EXTRA_RESET
#define EXTRA_RESET\
        extra_reset();

init() {
    ::init();
    add_action("join", "join");
    add_action("advance", "advance");
    add_action("info", "info");
    add_action("list", "list");
    add_action("check_advance_rec", "requirements");
    add_action("train", "train");
}    

extra_reset() {
     object plaque;
     if (!present("plaque")) {
        plaque = clone_object("world/guilds/plaque.c");
        move_object(plaque, this_object()); 
     }
}

guild_long_name() {
    return "the Priests.           ";
}

guild_name() {
    return "Priests";
}

guild_max_level() {
    return 10;
}

check_joining_rec() {
    if (this_player()->query_guild_level(call_other("/world/guilds/guildfun.c", "get_guild_number", "Apprentice Clerics")) != 10) {
        write("Must have completed the Appretice Clerics first.\n");
        return 0;
    }
    return 1;
}

check_advance_rec(lev) {
    if (!lev) { check_joining_rec(); }
    return 1;
}

/*
    10% Int, 25% Wis, 15% Con
*/

get_bonuses(level) {
    if (level == 0) {
        return "con 1 , wis 1 , spregen 2 , ";
    }
    if (level == 1) {
        return "int 1 , wis 1 , ";
    }
    if (level == 2) {
        return "con 2 , wis 2 , spregen 1 , ";
    }
    if (level == 3) {
        return "con 2 , int 2 , wis 2 , ";
    }
    if (level == 4) {
        return "int 1 , wis 1 , spregen 2 , ";
    }
    if (level == 5) {
        return "con 2 , int 1 , wis 2 , ";
    }
    if (level == 6) {
        return "int 1 , wis 2 , spregen 2 , ";
    }
    if (level == 7) {
        return "con 3 , int 2 , wis 3 , ";
    }
    if (level == 8) {
        return "con 1 , int 2 , wis 4 , ";
    }
    if (level == 9) {
        return "con 5 , wis 7 , spregen 3 , ";
    }
}
/*    
    Cast heal: 100%
*/

get_skill_max(num, how, lvl) {
    int skill_max, skill_num, i, guild_level;
    guild_level = this_player()->query_guild_level(call_other("/world/guilds/guildfun", "get_guild_number", guild_name()));
    if (lvl) {
         guild_level = lvl;
         if (guild_level > 10) { guild_level = 10; }
         if (guild_level < 1) { guild_level = 1; }
    }
    if (!guild_level) {
        write("Bugged.. not a member\n");
        return 0;
    }
    if (guild_level == 1) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 30;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 30;
    }
    if (guild_level == 2) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 35;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 35;
    }
    if (guild_level == 3) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 35;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 35;
    }
    if (guild_level == 4) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 40;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 40;
    }
    if (guild_level == 5) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 40;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 40;
    }
    if (guild_level == 6) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 45;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 45;
    }
    if (guild_level == 7) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 45;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 45;
    }
    if (guild_level == 8) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 50;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 50;
    }
    if (guild_level == 9) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 60;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 60;
    }
    if (guild_level == 10) {
        skill_max = allocate(2);
        skill_num = allocate(2);
        skill_num[0] = get_num("cast resurrect");
        skill_max[0] = 100;
        skill_num[1] = get_num("cast soul");
        skill_max[1] = 100;
    }                  
    if (how == 0) {
        while (i < sizeof(skill_max)) {
            if (skill_num[i] == num) {
                return skill_max[i];
            }
            i += 1;
        }  
    }
    if (how == 1) {
        return skill_max[num];
    }
    if (how == 2) {
        return skill_num[num];
    }
    if (how == 3) {
        return call_other("obj/skillfun", "skill_names", skill_num[num]);
    }
    if (how == 4) {
        return skill_max;
    }
}


special_advance_effect(lvl) {
    object ob;
    ob = present("spellbook", this_player());
    if (lvl == 2 && ob) {
	write("Your spellbook is surrounded by divine light.\n");
	ob->add_spell("Resurrect", "chl eth res");
    }
}	

ONE_EXIT("world/cleric/apprcler","down",
         "The Priests guild hall",
         "The Priests guild hall.\n"+
         "You are standing in a largish hall. The walls are made of pure\n" +
         "white marble. A peaceful silence rests upon you. You feel this is\n" +
         "the right place to pray and thank your god for everything.\n", 3)

