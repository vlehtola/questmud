inherit "room/room";

reset(arg) {
  if (arg) return;
  add_exit("south", "world/cleric/altar1");
  add_exit("west", "world/cleric/cleric");
  add_exit("east", "world/cleric/healer");
  add_exit("up", "world/cleric/priest");
  short_desc = "Cyral spellcaster center";
  long_desc = "Cyral spellcaster center.\n";
  set_not_out(1);
  set_light(3);
}
