inherit "obj/monster";

reset(arg) {
    string chat_str, a_chat_str;
    object money, weapon;
    ::reset(arg);
    set_level(20);
    set_exp(query_exp() / 5);
    set_name("priest");
    set_short("A priest of Cyral dressed in white robes");
    set_long(
"The priest is a devoted follower of Cyral the Sarced. Maybe you should\n"+
"listen to him.\n");
    set_al(70);
    set_al_aggr(500);
    set_aggressive(0);
    set_gender(1);
    if (!chat_str) {
        chat_str = allocate(2);
        chat_str[0] =
"Priest says: 'Sacrifice to the honor of Cyral the Sacred and she will help you on your way.'\n";
        chat_str[1] =
"Priest says: 'If you are in Cyral's favor, you can cast spells by her name;\n"+
"`cast {words} at {target} from cyral' instead of just the general\n"+
"presence of the gods.'\n";
    }
    if (!a_chat_str) {
        a_chat_str = allocate(1);
        a_chat_str[0] = "Priest screams: 'Cyral will avenge me!'\n";
    }
    load_chat(20, chat_str);
    load_a_chat(20, a_chat_str);
        
}

