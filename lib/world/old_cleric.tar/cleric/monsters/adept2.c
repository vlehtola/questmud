inherit "obj/monster";

reset(arg) {
    string chat_str, a_chat_str;
    object money, weapon;
    ::reset(arg);
    set_level(20);
    set_exp(query_exp() / 5);
    set_name("priest");
    set_short("A priest of Morai dressed in black robes");
    set_long(
"The priest is a devoted follower of Morai the Betrayer. Maybe you should\n"+
"listen to him.\n");
    set_al(-70);
    set_al_aggr(400);
    set_aggressive(0);
    set_gender(1);
    if (!chat_str) {
        chat_str = allocate(2);
        chat_str[0] =
"Priest says: 'Morai is the only true god. Serve him and you will grow in power.'\n";
        chat_str[1] =
"Priest says: 'If you are in Morai's favor, you can cast spells by his name;\n"+
"`cast {words} at {target} from morai' instead of just the general\n"+
"presence of the gods.'\n";
    }
    if (!a_chat_str) {
        a_chat_str = allocate(1);
	a_chat_str[0] = 
"Priest screams: 'Morai will torment you until the end of your days!'\n";
    }
    load_chat(20, chat_str);
    load_a_chat(20, a_chat_str);
}

