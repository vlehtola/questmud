inherit "obj/monster";

mapping loan;
int casting;

reset(arg) {
    string chat_str, a_chat_str;
    object money, weapon;
    if (arg) { return; }
    ::reset(arg);
    loan = ([ ]);

    set_level(100);
    set_exp(query_exp() / 5);
    set_name("Shann");
    set_alias("cleric");
    set_short("Shann the cleric of Cyral");
    set_long("Shann is a young woman clad in white robes. Maybe you"+
	"could pay her to receive some clerical services.\n");
    set_al(100);
    set_al_aggr(500);
    set_aggressive(0);
    set_gender(2);
    if (!chat_str) {
        chat_str = allocate(4);
        chat_str[0] = "Shann says: 'Scar removal costs 700 bronze coins'.\n";
	chat_str[2] = "Shann says: 'Reincarnation is free.'\n";
        chat_str[1] = "Shann reminds you: 'You will lose 15% of your total worth in reinc'\n";
    }
    if (!a_chat_str) {
        a_chat_str = allocate(1);
        a_chat_str[0] = "Priest screams: 'How do you DARE to fight in the church!'\n";
    }
    load_chat(20, chat_str);
    load_a_chat(20, a_chat_str);
}

init() {
  add_action("up", "up");
  add_action("ask","ask");
}

ask(arg) {
  string str;
  int i;
  if(!arg || sscanf(arg, "for %s",str) != 1) {
    write("Ask for what?\n");
    return 1;
  }
  if(casting) {
    write("Shann is busy now, come back later.\n");
    return 1;
  }
  casting = 1;
  if(str == "reinc" || str == "reincarnation") {
    tell_room(environment(this_object()),cap_name+ " says: 'Very well..'\n");
    tell_room(environment(this_object()),"Shann utters the magical word 'chl'\n");
    call_out("phase1",5,this_player());
    return 1;
  }
  write("No such a favor available.\n");
  casting = 0;
  return 1;
}

phase1(ob) {
  tell_room(environment(this_object()),"Shann utters the magical word 'eth'\n");
  call_out("phase2",5,ob);
}

phase2(ob) {
  tell_room(environment(this_object()),"Shann utters the magical word 'rnc'\n");
  call_out("do_reinc",1,ob);
}

do_reinc(ob) {
  casting = 0;
  if(!ob || ob->query_free_exp() != "0") {
    tell_room(environment(this_object()),"Shann aborts the casting.\n");
    if(ob) tell_object(ob, "Shann tells you 'You still have free exp on you.'\n");
    return 1;
  }
  tell_room(environment(this_object()),"Shann completes the spell.\n");
  call_other("/obj/spells/_chl_eth_rnc","resolve",0,ob->query_name(),0,1);
  move_object(ob,"/obj/race_selection");
}

add_loan(string str, num) {
  if (!str) { return; }
  str = lower_case(str);
  if (loan[str]) {
	return loan[str];
  }
  loan[str] = num;
}
