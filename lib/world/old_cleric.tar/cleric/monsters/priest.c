inherit "obj/monster";

reset(arg) {
    string chat_str, a_chat_str;
    object money, weapon;
    ::reset(arg);
    set_level(60);
    set_exp(query_exp() / 5);
    set_name("jequal");
    set_alias("priest");
    set_short("Jequal the priest of Neutrality");
    set_long("This man is old and gray haired. He is wearing gray robes.\n");
    set_al(0);
    set_al_aggr(400);
    set_aggressive(0);
    set_gender(1);
    if (!chat_str) {
        chat_str = allocate(4);
        chat_str[0] =
"Jequal says: 'Oh, I still remember the time when the two religions were\n"+
"like one'.\n";
        chat_str[1] =
"Jequal says: 'This church was built in the time when both gods still\n"+
"respected each other'.\n";
        chat_str[2] =
"Jequal says: 'It's nearly a miracle that the both religions still are\n"+
"practised in this same building and without any greater conflicts.\n";
        chat_str[3] =
"Jequal says: 'Now days the people of Duranghom worship two gods. Cyral\n"+
"and Morai.\n"; 
    }
    if (!a_chat_str) {
        a_chat_str = allocate(1);
        a_chat_str[0] = "Priest screams: 'How do you DARE to fight in the church!'\n";
    }
    load_chat(20, chat_str);
    load_a_chat(20, a_chat_str);
}

init() {
  add_action("up", "up");
}

up() {
if(this_player()->query_guild_level(call_other("world/guilds/guildfun.c",
               "get_guild_number", "Apprentice Clerics")) != 10) {
	write("Jequal says: 'Sorry, but that place is only for fully learned clerics'.\n");
	return 1;
  }
}
