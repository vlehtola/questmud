inherit "room/room";

reset(arg) {
  if (arg) return;
  short_desc = "Entrance hall to the Granters guild";
  long_desc =
"You are in a hall leading to the Granters guild complex.\n"+
"The Endurance Adepts lie to the northwest, the Mana Adepts north\n"+
"and the Durability Adepts northeast.\n";
  add_exit("south", "/wizards/grathlek/area1/eroom3");
  add_exit("northwest", "/world/cleric/unpain/hp");
  add_exit("north", "/world/cleric/unpain/sp");
  add_exit("northeast", "/world/cleric/unpain/ep");
}
