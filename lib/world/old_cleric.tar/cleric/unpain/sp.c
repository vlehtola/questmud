inherit "world/guilds/guild";
inherit "room/room";

reset(arg) {
  object plaque;
  if (!present("plaque")) {
    plaque = clone_object("world/guilds/plaque.c");
    move_object(plaque, this_object());
  }
  if(arg) return;
  add_exit("north","/world/cleric/unpain/unpain");
  add_exit("south","/world/cleric/unpain/entrance");
  short_desc = "The Mana Adepts guild";
  long_desc =
"You are in the Mana Adepts guild room. The room is lighted with oil\n"+
"lamps.\n";
}

init() {
  ::init();
  guild_init();
}

guild_max_level() {
  return 2;
}

guild_long_name() {
    return "Mana Adepts";
}
guild_name() {
    return "Mana Adepts";
}

check_joining_rec() {
    if(this_player()->query_guild_level(call_other("/world/guilds/guildfun",
"get_guild_number", "Healers")) < 10) {
        write("You must have completed the Healers guild first.\n");
        return 0;
    }
    return 1;
}

check_advance_rec(lev) {
  mapping sk;
  sk = ([ ]);
  if(lev == 2 && this_player()->query_level() < 10) return 0;
  if(this_player()->query_wiz()) write("Check_advance done.\n");
  return sk;
}

/*
  Stats:  
*/

get_bonuses(level) {
  if (level == 0) return "wis 1 , ";
  if (level == 1) return "int 3 , ";
}
/*
  Skills:
    cast endurance: 100
*/
get_skill_max(num, how, lvl) {
    mapping skill;
    int skill_max, skill_num, i, guild_level;
    guild_level = this_player()->query_guild_level(call_other("/world/guilds/guildfun", "get_guild_number", guild_name()));
    skill = ([ ]);

    if (lvl) {
         guild_level = lvl;
         if (guild_level > guild_max_level()) { 
		guild_level = guild_max_level(); 
	 }
    }
    if (!guild_level) {
        write("Bugged.. not a member\n");
        return 0;
    }
    if (guild_level >= 1) {
      skill += (["cast mana":(int) 50]);
    }
    if (guild_level >= 2) {
      skill += (["cast mana":(int) 100]);
    }
    skill_num = m_indices(skill);
    skill_max = m_values(skill);
    if (how == 0) {
        while (i < sizeof(skill_max)) {
            if (skill_num[i] == num) {
                return skill_max[i];
            }
            i += 1;
        }  
    }
    if (how == 1) {
        return skill_max[num];
    }
    if (how == 2 || how == 3) {
        return skill_num[num];
    }
    if (how == 4) {
        return skill_max;
    }
}

