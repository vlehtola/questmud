inherit "world/guilds/guild";
inherit "room/room";

reset(arg) {
  object plaque;
  if (!present("plaque")) {
    plaque = clone_object("world/guilds/plaque.c");
    move_object(plaque, this_object());
  }
  if(arg) return;
  add_exit("southwest","/world/cleric/unpain/hp");
  add_exit("south","/world/cleric/unpain/sp");
  add_exit("southeast","/world/cleric/unpain/ep");
  short_desc = "The Granters training area";
  long_desc =
"You are in the Granters guilds training room. The room is filled with a\n"+
"sweat odour. There area oil lamps in each corner of the room.\n"+
"The Endurance Adepts training room is located to the southwest, Mana Adepts\n"+
"south and Durability Adepts southeast.\n";

}

init() {
  ::init();
  guild_init();
}

guild_max_level() {
  return 6;
}

guild_long_name() {
    return "Granters";
}
guild_name() {
    return "Granters";
}

check_joining_rec() {
    if(this_player()->query_guild_level(call_other("/world/guilds/guildfun",
"get_guild_number", "Mana Adepts")) == 2 || 
this_player()->query_guild_level(call_other("/world/guilds/guildfun",
"get_guild_number", "Endurance Adepts")) == 2 ||
this_player()->query_guild_level(call_other("/world/guilds/guildfun",
"get_guild_number", "Durability Adepts")) == 2) {
        return 1;
    }
    write("You must have completed atleast one:\n");
    write("	The Mana Adepts\n");
    write("	The Endurance Adepts\n");
    write("	The Durability Adepts\n");
    return 0;
}

check_advance_rec(lev) {
  mapping sk;
  sk = ([ ]);
  if(lev == 2 && this_player()->query_level() < 10) return 0;
  if(this_player()->query_wiz()) write("Check_advance done.\n");
  return sk;
}

/*
  Stats:  
    30% Str, 20% Con
    Hpregen: 5
    Hpmax: 50
*/

get_bonuses(level) {
  if (level == 0) return "wis 1 , ";
  if (level == 1) return "spregen 1 , ";
  if (level == 2) return "con 2 , ";
  if (level == 3) return "wis 3 , ";
  if (level == 4) return "con 2 , spregen 2 , ";
  if (level == 5) return "wis 4 , ";
}
/*
  Skills:
    cast regeneration 100
    cast grant: 100
*/
get_skill_max(num, how, lvl) {
    mapping skill;
    int skill_max, skill_num, i, guild_level;
    guild_level = this_player()->query_guild_level(call_other("/world/guilds/guildfun", "get_guild_number", guild_name()));
    skill = ([ ]);

    if (lvl) {
         guild_level = lvl;
         if (guild_level > guild_max_level()) { 
		guild_level = guild_max_level(); 
	 }
    }
    if (!guild_level) {
        write("Bugged.. not a member\n");
        return 0;
    }
    if (guild_level >= 1) {
      skill += (["cast grant":(int) 20]);
    }
    if (guild_level >= 2) {
      skill += (["cast grant":(int) 40]);
    }
    if (guild_level >= 3) {
      skill += (["cast grant":(int) 50]);
    }
    if (guild_level >= 4) {
      skill += (["cast grant":(int) 60]);
      skill += (["cast regeneration":(int) 30]);
    }
    if (guild_level >= 5) {
      skill += (["cast grant":(int) 80]);
      skill += (["cast regeneration":(int) 60]);
    }
    if (guild_level >= 6) {
      skill += (["cast grant":(int) 100]);
      skill += (["cast regeneration":(int) 100]);
    }
    skill_num = m_indices(skill);
    skill_max = m_values(skill);
    if (how == 0) {
        while (i < sizeof(skill_max)) {
            if (skill_num[i] == num) {
                return skill_max[i];
            }
            i += 1;
        }  
    }
    if (how == 1) {
        return skill_max[num];
    }
    if (how == 2 || how == 3) {
        return skill_num[num];
    }
    if (how == 4) {
        return skill_max;
    }
}

